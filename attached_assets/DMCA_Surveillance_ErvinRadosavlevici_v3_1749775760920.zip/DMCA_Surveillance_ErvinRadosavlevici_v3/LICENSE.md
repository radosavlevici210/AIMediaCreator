# LICENSE - Master License (Immutable)

Protected under the sole ownership of: Ervin Remus Radosavlevici  
Hash: 7c3de7b1a4da6efb54c86653320bdee90ea3449f

Unauthorized copying, re-uploading, or usage is forbidden. All rights reserved.  
Payment and royalty rights are bound to:

IBAN: GB45 NAIA 0708 0620 7951 39  
BIC: NAIAGB21  
SWIFT Intermediary: MIDLGB22

© 2025 Ervin Remus Radosavlevici
